#mi primer analizador lexico que solo me reconocer 
# numeros enteros, identificadores, operadores
# librerias: lexico, re

import re

#crear tokens
token_patterns = [
('Numeros',      r'\d+(\.\d*)?'),           # 1 Números enteros o de punto flotante
('IF',          r'\bif\b'),                # 2 Palabra clave if
('ELSE',        r'\belse\b'),              # 3 Palabra clave else
('WHILE',       r'\bwhile\b'),             # 4 Palabra clave while
('RETURN',      r'\breturn\b'),            # 5 Palabra clave return
('FUNCTION',    r'\bfunction\b'),          # 6 Palabra clave function
('VAR',         r'\bvar\b'),               # 7 Palabra clave var
('CONST',       r'\bconst\b'),             # 8 Palabra clave const
('TRUE',        r'\btrue\b'),              # 9 Booleano true
('FALSE',       r'\bfalse\b'),             # 10 Booleano false
('NULL',        r'\bnull\b'),              # 11 Valor nulo  
('Identificadores',          r'[A-Za-z_]\w*'),          # 12 Identificadores
('Asignación',      r'='),                     # 13 Operador de asignación
('Suma',        r'\+'),                    # 14 Operador de suma
('Resta',       r'-'),                     # 15 Operador de resta
('Multiplicación',        r'\*'),                    # 16 Operador de multiplicación
('División',         r'/'),                     # 17 Operador de división
('Porcentaje',         r'%'),                     # 18 Operador de módulo
('Menor_que',          r'<'),                     # 19 Menor que
('Mayor_que',          r'>'),                     # 20 Mayor que
('Diferente_De',          r'!='),                    # 21 Diferente de
('AND',         r'&&'),                    # 22 Operador lógico AND
('OR',          r'\|\|'),                  # 23 Operador lógico OR
('NOT',         r'!'),                     # 24 Operador lógico NOT
('PARENTESIS_IZQ',      r'\('),                    # 25 Paréntesis izquierdo
('PARENTESIS_DER',      r'\)'),                    # 26 Paréntesis derecho
('LLave_IZQ',      r'\{'),                    # 27 Llave izquierda
('LLave_DER',      r'\}'),                    # 28 Llave derecha
('Corchete_IZQ',    r'\['),                    # 29 Corchete izquierdo
('Corchete_DER',    r'\]'),                    # 30 Corchete derecho
('Punto_y_coma',        r';'),                     # 31 Punto y coma
('Dos_Puntos',       r':'),                     # 32 Dos puntos
('Coma',       r','),                     # 33 Coma
('Punto',         r'\.'),                    # 34 Punto
('CHAR',        r'\'[^\'\\]*(?:\\.[^\'\\]*)*\''), # 35 Caracteres
('Linea_Nueva',     r'\n'),                    # 36 Línea nueva
('Espacio',        r'[ \t]+'),                # 37 Espacios y tabuladores (ignorar)
('FOR',         r'\bfor\b'),               # 38 Palabra clave for
('DOLAR',      r'\$'),                    # 39 Signo de dólar
('Signo_de_Numero',        r'#'),                     # 40 Signo de número
('Ampersand',         r'&'),                     # 41 Ampersand
('Signo_de_interrogación',    r'\?'),                    # 42 Signo de interrogación
('Exclamacion_Invertido', r'¡'),                    # 43 Signo de exclamación invertido
('comillas_simples',       r'\'|\"'),                # 44 Comillas simples y dobles
('Interrogación_Invertido', r'¿'),             # 45 Signo de interrogación invertido
('TILDE',       r'~'),                     # 46 Virgulilla
('Acento_grave',    r'`'),                     # 47 Acento grave
('Circunflejo',       r'\^'),                    # 48 Circunflejo
('Arroba',          r'@'),                     # 49 Arroba
('Negación',         r'¬'),                     # 50 Signo de negación
('Grado',      r'°'),                     # 51Grado
('MISMATCH',    r'.'),                     # 52 Cualquier otro carácter
]

# token expresiones regulares patrones
token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_patterns)
get_token = re.compile(token_regex).match

def tokenize(code):
    line_number = 1
    line_start = 0
    position = 0
    tokens = []
    counter = 1

    while position < len(code):
        match = get_token(code, position)
        if not match:
            raise RuntimeError(f'Error de Analisis en posicion {position}')
        
        for name, value in match.groupdict().items():
            if value:
                if name != 'ESPACIO':
                    tokens.append((counter, name, value))
                    counter = 1+counter
                break
        position = match.end()

    return tokens  # Mover el return fuera del bucle while



code = "1I=+-*/%<>!=&&||!(){}[];:,.'hola'\n$#&?¡'¿~`^@¬°if else while return function var const true false null"  
tokens = tokenize(code)
for token in tokens:
    print(token)

    